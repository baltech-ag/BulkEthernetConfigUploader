This zip-File contains the transport keys for Nuance Readers produced by BALTECH AG. It allows authentication with BALTECH readers in factory state. If you encounter this file outside of a relevant context, please help us identify this security leak by writing to info@baltech.de.

BALTECH AG, Hallbergmoos, Germany, 2016